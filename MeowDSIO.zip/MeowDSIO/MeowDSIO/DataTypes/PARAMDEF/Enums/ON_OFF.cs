﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeowDSIO.DataTypes.PARAMDEF.Enums
{
    public enum ON_OFF : byte
    {
        OFF = 0,
        ON = 1,
    }
}
