# MeowDSIO
Overly fancy API for various Dark Souls file formats.
