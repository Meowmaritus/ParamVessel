import clr
import System
clr.AddReference("DarkSoulsScripting")
from DarkSoulsScripting import *
from DarkSoulsScripting.Extra import *
from DarkSoulsScripting.AI_DEFINE import *
from DarkSoulsScripting.XInput import Gamepad
from DarkSoulsScripting import IngameFuncs as f
from DarkSoulsScripting import ExtraFuncs as ex