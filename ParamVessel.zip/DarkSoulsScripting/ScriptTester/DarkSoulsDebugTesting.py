from DarkSoulsScriptingBundle import *

print str(f.GetEventMode(1501961))