﻿using System.Windows;

namespace DarkSoulsScripting.DebugUI
{
    /// <summary>
    /// Interaction logic for WpfPropertyGrid.xaml
    /// </summary>
    public partial class InspectGUI : Window
    {
        public InspectGUI()
        {
            InitializeComponent();
        }
    }
}
