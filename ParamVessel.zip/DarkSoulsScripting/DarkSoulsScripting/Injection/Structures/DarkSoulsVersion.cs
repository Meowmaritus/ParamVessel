﻿namespace DarkSoulsScripting.Injection.Structures
{
    public enum DarkSoulsVersion
    {
        None,
        LatestRelease,
        SteamWorksBeta,
        Debug,
        AncientGFWL
    }
}