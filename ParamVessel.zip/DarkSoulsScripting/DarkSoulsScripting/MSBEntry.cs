﻿namespace DarkSoulsScripting
{
    //UNDER CONSTRUCTION
    public class MSBEntry : GameStruct
    {

        protected override void InitSubStructures()
        {
            
        }
    }

}
