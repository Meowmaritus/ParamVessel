﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DarkSoulsScripting
{
    //TODO: Move all Equip* from PlayerStats to here with names matching those in debug menu
    public class ChrAsm : GameStruct
    {
        protected override void InitSubStructures()
        {
            
        }
    }
}
