﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeowDSIO.DataTypes.BND
{
    public enum BndVersion
    {
        Invalid = -1,
        BND3 = 3,
        BND4 = 4
    }
}
