﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeowDSIO.DataTypes.REMOBND
{
    public class RemoCutEntry
    {
        public byte[] Sibcam { get; set; } = null;
        public byte[] Hkx { get; set; } = null;
    }
}
